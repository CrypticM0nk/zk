require('@nomiclabs/hardhat-waffle');
module.exports = {};